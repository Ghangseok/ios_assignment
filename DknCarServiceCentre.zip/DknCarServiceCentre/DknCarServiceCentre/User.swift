//
//  Users.swift
//  DknCarServiceCentre
//
//  Created by h06 on 2017-03-28.
//  Copyright © 2017 daniel.karamjeet.nari.com. All rights reserved.
//

import Foundation

struct User {
    static var username : String = "";
    static var name : String = "";
}
